// Runs in the PAGE's JS world (manifest: "world": "MAIN") so it can call the YouTube player API.
// youtube-tweaks.js (isolated world) talks to it with window.postMessage.
// This replaces the old inline <script> injection, which YouTube's CSP / Trusted Types can block in Chrome.
(function () {
  'use strict';
  if (window.__zoocageYTMain) return;
  window.__zoocageYTMain = true;

  // ---------------- quality ----------------
  class YTQuality {
    constructor(defaultQuality) {
      this.defaultQuality = defaultQuality || 'medium';
      this.player = null;
    }

    init() {
      this.waitForPlayer();
      this.observeNavigation();
    }

    waitForPlayer() {
      const checkPlayer = setInterval(() => {
        this.player = document.querySelector('.html5-video-player');
        if (this.player && typeof this.player.getAvailableQualityLevels === 'function') {
          const levels = this.player.getAvailableQualityLevels();
          if (levels && levels.length > 0) {
            clearInterval(checkPlayer);
            this.updatePlayerQuality();
          }
        }
      }, 500);
      setTimeout(() => clearInterval(checkPlayer), 30000);
    }

    observeNavigation() {
      document.addEventListener('yt-navigate-finish', () => {
        setTimeout(() => this.waitForPlayer(), 500);
      });
    }

    setQuality(quality) {
      this.defaultQuality = quality;
      this.updatePlayerQuality();
    }

    updatePlayerQuality() {
      if (!this.player) this.player = document.querySelector('.html5-video-player');
      if (this.player) {
        try {
          if (typeof this.player.setPlaybackQualityRange === 'function') {
            this.player.setPlaybackQualityRange(this.defaultQuality, this.defaultQuality);
          }
          if (typeof this.player.setPlaybackQuality === 'function') {
            this.player.setPlaybackQuality(this.defaultQuality);
          }
        } catch (ex) {}
      }
    }
  }

  // ---------------- original audio track ----------------
  const ytAudio = {
    enabled: false,
    timer: null,

    info(track) {
      const out = { id: '', isDefault: false, text: '' };
      const seen = new Set();
      const walk = (o, d) => {
        if (!o || typeof o !== 'object' || d > 3 || seen.has(o)) return;
        seen.add(o);
        for (const k in o) {
          let v;
          try { v = o[k]; } catch (e) { continue; }
          if (k === 'audioIsDefault' && v === true) out.isDefault = true;
          if (k === 'id' && typeof v === 'string' && !out.id) out.id = v;
          if (typeof v === 'string') out.text += ' ' + v.toLowerCase();
          else if (v && typeof v === 'object') walk(v, d + 1);
        }
      };
      walk(track, 0);
      return out;
    },

    pickOriginal(tracks) {
      const infos = tracks.map((t) => ({ t: t, i: this.info(t) }));
      let hit = infos.find((x) => x.i.isDefault);
      if (!hit) hit = infos.find((x) => /original/.test(x.i.text));
      if (!hit) {
        const nonDub = infos.filter((x) => !/dubbed/.test(x.i.text));
        if (nonDub.length === 1) hit = nonDub[0];
      }
      return hit || null;
    },

    apply(player) {
      try {
        const tracks = player.getAvailableAudioTracks();
        if (!tracks || tracks.length < 2) return;
        const target = this.pickOriginal(tracks);
        if (!target) return;
        const cur = player.getAudioTrack && player.getAudioTrack();
        const curId = cur ? this.info(cur).id : '';
        const same = curId && target.i.id ? curId === target.i.id : cur === target.t;
        if (!same) player.setAudioTrack(target.t);
      } catch (e) {}
    },

    run() {
      clearInterval(this.timer);
      if (!this.enabled) return;
      let tries = 0;
      this.timer = setInterval(() => {
        tries++;
        if (tries > 30) { clearInterval(this.timer); return; }
        const player = document.querySelector('.html5-video-player');
        if (!player || typeof player.getAvailableAudioTracks !== 'function') return;
        let tracks;
        try { tracks = player.getAvailableAudioTracks(); } catch (e) { return; }
        if (!tracks || tracks.length < 2) return;
        clearInterval(this.timer);
        this.apply(player);
        setTimeout(() => this.apply(player), 2500);
      }, 500);
    },

    sync(enabled) {
      this.enabled = !!enabled;
      this.run();
    },
  };

  document.addEventListener('yt-navigate-finish', () => {
    setTimeout(() => ytAudio.run(), 300);
  });

  // ---------------- commands from youtube-tweaks.js ----------------
  let quality = null;

  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || e.data.__zoocage !== true) return;
    const { cmd, arg } = e.data;

    if (cmd === 'initQuality') {
      if (!quality) {
        quality = new YTQuality(arg);
        quality.init();
      } else {
        quality.setQuality(arg);
      }
    } else if (cmd === 'setQuality') {
      if (quality) quality.setQuality(arg);
    } else if (cmd === 'updateQuality') {
      if (quality) quality.updatePlayerQuality();
    } else if (cmd === 'syncAudio') {
      ytAudio.sync(arg);
    }
  });
})();

(function () {
  "use strict";

  let settings = {
    defaultQuality: "auto",
    hideRecommended: false,
    hideShorts: false,
    hideComments: false,
    hideExplore: false,
    hideMoreFromYoutube: false,
    disableAutoplay: false,
    hideEndCards: false,
    hideAnnotations: false,
    defaultAudioTrack: false,
    hideSponsored: false,
  };

  let styleElements = {};
  let lastUrl = null;
  let autoplayObserver = null;

  const qualityMap = {
    auto: "Auto",
    "144p": "tiny",
    "240p": "small",
    "360p": "medium",
    "480p": "large",
    "720p": "hd720",
    "1080p": "hd1080",
    "1440p": "hd1440",
    "2160p": "hd2160",
  };

  function sendToPage(cmd, arg) {
    window.postMessage({ __zoocage: true, cmd, arg }, "*");
  }
  function initQualityScript(quality) { sendToPage("initQuality", quality); }
  function syncAudioScript(enabled) { sendToPage("syncAudio", !!enabled); }
  function updatePlayerQuality() { sendToPage("updateQuality"); }
  function setQuality(quality) { sendToPage("setQuality", quality); }

  function applyDarkSearchFilters() {
    if (!styleElements.darkFilters) {
      const style = document.createElement("style");
      style.id = "zoocage-dark-filters";
      style.textContent = `
              /* Search filter dialog */
              ytd-search-filter-options-dialog-renderer,
              tp-yt-paper-dialog,
              tp-yt-paper-dialog .dialog-container,
              ytd-search-filter-group-renderer,
              ytd-search-filter-renderer {
                  background-color: #1a1a1a !important;
                  color: #e0e0e0 !important;
              }

              ytd-search-filter-options-dialog-renderer .title,
              ytd-search-filter-group-renderer .filter-group-name,
              ytd-search-filter-group-renderer .title {
                  color: #e0e0e0 !important;
              }

              ytd-search-filter-renderer a,
              ytd-search-filter-renderer .filter-label,
              ytd-search-filter-renderer .simpleText,
              ytd-search-filter-renderer yt-formatted-string {
                  color: #b0b0b0 !important;
              }

              ytd-search-filter-renderer a:hover,
              ytd-search-filter-renderer a:hover yt-formatted-string {
                  color: #ffffff !important;
              }

              /* Selected/active filter */
              ytd-search-filter-renderer[is-selected] yt-formatted-string,
              ytd-search-filter-renderer[aria-selected="true"] yt-formatted-string {
                  color: #3ea6ff !important;
              }

              /* Dialog backdrop */
              tp-yt-paper-dialog-scrollable {
                  background-color: #1a1a1a !important;
              }

              /* Dividers */
              ytd-search-filter-group-renderer #separator,
              ytd-search-filter-options-dialog-renderer .separator {
                  border-color: #333 !important;
              }
          `;
      (document.head || document.documentElement).appendChild(style);
      styleElements.darkFilters = style;
    }
  }

  async function loadSettings() {
    const result = await browser.storage.local.get("youtubeSettings");
    if (result.youtubeSettings) {
      settings = { ...settings, ...result.youtubeSettings };
    }
    applySettings();
  }

  function applySettings() {
    applyHideRecommended();
    applyHideShorts();
    applyHideComments();
    applyHideExplore();
    applyHideMoreFromYoutube();
    applyDisableAutoplay();
    applyHideEndCards();
    applyHideAnnotations();
    applyDarkSearchFilters();
    applyHideSponsored();

    const quality = qualityMap[settings.defaultQuality] || "medium";
    initQualityScript(quality);
    syncAudioScript(settings.defaultAudioTrack);

    const anyOptionChecked =
      settings.hideRecommended ||
      settings.hideShorts ||
      settings.hideComments ||
      settings.hideExplore ||
      settings.hideMoreFromYoutube ||
      settings.disableAutoplay ||
      settings.hideEndCards ||
      settings.hideAnnotations;

    if (!anyOptionChecked) {
      setTimeout(() => updatePlayerQuality(), 2000);
    }
  }

  function applyHideRecommended() {
    if (settings.hideRecommended) {
      if (!styleElements.recommended) {
        const style = document.createElement("style");
        style.id = "zoocage-hide-recommended";
        style.textContent = `
                    ytd-watch-next-secondary-results-renderer,
                    #related,
                    #secondary,
                    ytd-compact-video-renderer,
                    ytd-shelf-renderer {
                        display: none !important;
                    }
                `;
        (document.head || document.documentElement).appendChild(style);
        styleElements.recommended = style;
      }
    } else {
      if (styleElements.recommended) {
        styleElements.recommended.remove();
        delete styleElements.recommended;
      }
    }
  }

  function applyHideShorts() {
    if (settings.hideShorts) {
      if (!styleElements.shorts) {
        const style = document.createElement("style");
        style.id = "zoocage-hide-shorts";
        style.textContent = `
                    ytd-reel-shelf-renderer,
                    ytd-guide-entry-renderer a[title="Shorts"],
                    ytd-mini-guide-entry-renderer[aria-label="Shorts"],
                    [is-shorts],
                    a[href*="/shorts/"],
                    ytd-rich-shelf-renderer[is-shorts],
                    tp-yt-paper-tab a[href="/shorts"],
                    yt-tab-shape[tab-title="Shorts"] {
                        display: none !important;
                    }
                `;
        (document.head || document.documentElement).appendChild(style);
        styleElements.shorts = style;
      }
    } else {
      if (styleElements.shorts) {
        styleElements.shorts.remove();
        delete styleElements.shorts;
      }
    }
  }

  function applyHideComments() {
    if (settings.hideComments) {
      if (!styleElements.comments) {
        const style = document.createElement("style");
        style.id = "zoocage-hide-comments";
        style.textContent = `
                    ytd-comments,
                    #comments,
                    ytd-item-section-renderer#sections:has(#comments) {
                        display: none !important;
                    }
                `;
        (document.head || document.documentElement).appendChild(style);
        styleElements.comments = style;
      }
    } else {
      if (styleElements.comments) {
        styleElements.comments.remove();
        delete styleElements.comments;
      }
    }
  }

  function applyHideExplore() {
    if (settings.hideExplore) {
      if (!styleElements.explore) {
        const style = document.createElement("style");
        style.id = "zoocage-hide-explore";
        style.textContent = `
                    ytd-guide-section-renderer:has(ytd-guide-entry-renderer a[title="Trending"]),
                    ytd-guide-section-renderer:has(ytd-guide-entry-renderer a[title="Shopping"]),
                    ytd-guide-entry-renderer:has(a[title="Trending"]),
                    ytd-guide-entry-renderer:has(a[title="Shopping"]),
                    ytd-guide-entry-renderer:has(a[title="Music"]),
                    ytd-guide-entry-renderer:has(a[title="Movies & TV"]),
                    ytd-guide-entry-renderer:has(a[title="Movies"]) {
                        display: none !important;
                    }
                `;
        (document.head || document.documentElement).appendChild(style);
        styleElements.explore = style;
      }
    } else {
      if (styleElements.explore) {
        styleElements.explore.remove();
        delete styleElements.explore;
      }
    }
  }

  function applyHideMoreFromYoutube() {
    if (settings.hideMoreFromYoutube) {
      if (!styleElements.more) {
        const style = document.createElement("style");
        style.id = "zoocage-hide-more";
        style.textContent = `
                    ytd-guide-section-renderer:has(ytd-guide-entry-renderer a[title="YouTube Premium"]),
                    ytd-guide-section-renderer:has(ytd-guide-entry-renderer a[title="YouTube TV"]),
                    ytd-guide-section-renderer:has(ytd-guide-entry-renderer a[title="YouTube Music"]),
                    ytd-guide-section-renderer:has(ytd-guide-entry-renderer a[title="YouTube Kids"]),
                    ytd-guide-collapsible-section-entry-renderer,
                    ytd-guide-entry-renderer:has(a[title="YouTube Premium"]),
                    ytd-guide-entry-renderer:has(a[title="YouTube TV"]),
                    ytd-guide-entry-renderer:has(a[title="YouTube Music"]),
                    ytd-guide-entry-renderer:has(a[title="YouTube Kids"]),
                    ytd-guide-entry-renderer:has(a[title="YouTube Studio"]),
                    ytd-guide-entry-renderer:has(a[title="YouTube Creator Academy"]) {
                        display: none !important;
                    }
                `;
        (document.head || document.documentElement).appendChild(style);
        styleElements.more = style;
      }
    } else {
      if (styleElements.more) {
        styleElements.more.remove();
        delete styleElements.more;
      }
    }
  }

  function applyHideEndCards() {
    if (settings.hideEndCards) {
      if (!styleElements.endcards) {
        const style = document.createElement("style");
        style.id = "zoocage-hide-endcards";
        style.textContent = `
                    .ytp-ce-element,
                    .ytp-cards-teaser,
                    .ytp-ce-covering-overlay,
                    .ytp-ce-element-show,
                    .ytp-ce-covering-image,
                    .ytp-ce-expanding-image,
                    .ytp-ce-element.ytp-ce-video-image-element,
                    .ytp-ce-element.ytp-ce-channel-this-video-element,
                    .ytp-pause-overlay,
                    .ytp-endscreen-content,
                    .ytp-ce-video,
                    .ytp-ce-playlist,
                    .ytp-ce-website,
                    .ytp-ce-channel,
                    .html5-endscreen,
                    .ytp-ce-shadow,
                    .ytp-ce-size-1280,
                    .ytp-ce-top-left-quad,
                    .ytp-ce-top-right-quad,
                    .ytp-ce-bottom-left-quad,
                    .ytp-ce-bottom-right-quad,
                    .ytp-cards-button,
                    .ytp-cards-teaser-box,
                    .ytp-suggestion-set {
                        display: none !important;
                        visibility: hidden !important;
                        opacity: 0 !important;
                        pointer-events: none !important;
                    }
                `;
        (document.head || document.documentElement).appendChild(style);
        styleElements.endcards = style;
      }

      if (!window.endcardsObserver) {
        const removeEndCards = () => {
          const endCardSelectors = [
            ".ytp-ce-element",
            ".ytp-endscreen-content",
            ".html5-endscreen",
            ".ytp-ce-covering-overlay",
            ".ytp-pause-overlay",
            ".ytp-cards-teaser",
            ".ytp-suggestion-set",
          ];

          endCardSelectors.forEach((selector) => {
            document.querySelectorAll(selector).forEach((el) => {
              el.remove();
            });
          });
        };

        removeEndCards();

        window.endcardsObserver = new MutationObserver(() => {
          removeEndCards();
        });

        const checkPlayer = setInterval(() => {
          const player = document.querySelector(".html5-video-player");
          if (player) {
            clearInterval(checkPlayer);
            window.endcardsObserver.observe(player, {
              childList: true,
              subtree: true,
            });
            setInterval(removeEndCards, 1000);
          }
        }, 500);

        setTimeout(() => clearInterval(checkPlayer), 10000);
      }
    } else {
      if (styleElements.endcards) {
        styleElements.endcards.remove();
        delete styleElements.endcards;
      }

      if (window.endcardsObserver) {
        window.endcardsObserver.disconnect();
        window.endcardsObserver = null;
      }
    }
  }

  function applyHideAnnotations() {
      if (settings.hideAnnotations) {
          if (!styleElements.annotations) {
              const style = document.createElement("style");
              style.id = "zoocage-hide-annotations";
              style.textContent = `
                      .annotation,
                      .video-annotations,
                      .iv-branding,
                      .iv-branding-text,
                      .iv-drawer,
                      .iv-card,
                      .iv-promo,
                      .ytp-ce-element[data-is-annotation],
                      ytd-player-legacy-desktop-watch-ads-renderer,
                      .html5-video-player .annotation-container {
                          display: none !important;
                          visibility: hidden !important;
                          opacity: 0 !important;
                          pointer-events: none !important;
                      }
                  `;
              (document.head || document.documentElement).appendChild(style);
              styleElements.annotations = style;
          }

          if (!window.annotationsObserver) {
              const removeAnnotations = () => {
                  const annotationSelectors = [
                      ".annotation",
                      ".video-annotations",
                      ".iv-branding",
                      ".iv-drawer",
                      ".iv-card",
                      ".iv-promo",
                  ];

                  annotationSelectors.forEach((selector) => {
                      document.querySelectorAll(selector).forEach((el) => {
                          el.remove();
                      });
                  });
              };

              removeAnnotations();

              window.annotationsObserver = new MutationObserver(() => {
                  removeAnnotations();
              });

              const checkPlayer = setInterval(() => {
                  const player = document.querySelector(".html5-video-player");
                  if (player) {
                      clearInterval(checkPlayer);
                      window.annotationsObserver.observe(player, {
                          childList: true,
                          subtree: true,
                      });
                      setInterval(removeAnnotations, 1000);
                  }
              }, 500);

              setTimeout(() => clearInterval(checkPlayer), 10000);
          }
      } else {
          if (styleElements.annotations) {
              styleElements.annotations.remove();
              delete styleElements.annotations;
          }

          if (window.annotationsObserver) {
              window.annotationsObserver.disconnect();
              window.annotationsObserver = null;
          }
      }
  }

  let autoplayTimer = null;
  let autoplayNavHandler = null;

  function applyDisableAutoplay() {
    if (autoplayObserver) {
      autoplayObserver.disconnect();
      autoplayObserver = null;
    }
    clearInterval(autoplayTimer);
    autoplayTimer = null;

    if (autoplayNavHandler) {
      document.removeEventListener("yt-navigate-finish", autoplayNavHandler);
      autoplayNavHandler = null;
    }

    if (!settings.disableAutoplay) return;

    // Returns true once the toggle was found, so polling can stop
    const turnOff = () => {
      if (location.pathname !== "/watch") return false;
      const btn = document.querySelector(".ytp-autonav-toggle-button");
      if (!btn) return false;
      if (btn.getAttribute("aria-checked") === "true") btn.click();
      return true;
    };

    const start = () => {
      clearInterval(autoplayTimer);
      autoplayTimer = null;
      if (location.pathname !== "/watch") return; // never touch search, home, etc.
      let tries = 0;
      autoplayTimer = setInterval(() => {
        tries++;
        if (turnOff() || tries >= 20) {
          clearInterval(autoplayTimer);
          autoplayTimer = null;
        }
      }, 500);
    };

    autoplayNavHandler = () => setTimeout(start, 300);
    document.addEventListener("yt-navigate-finish", autoplayNavHandler);
    start();
  }

  let sponsoredObserver = null;
  let sponsoredTimer = null;

  function applyHideSponsored() {
    if (settings.hideSponsored) {
      if (!styleElements.sponsored) {
        const style = document.createElement("style");
        style.id = "zoocage-hide-sponsored";
        const selectors = [
          "ytd-ad-slot-renderer",
          "ytd-in-feed-ad-layout-renderer",
          "ytd-promoted-sparkles-web-renderer",
          "ytd-promoted-video-renderer",
          "ytd-display-ad-renderer",
          "ytd-search-pyv-renderer",
          "ytd-banner-promo-renderer",
          "ytd-statement-banner-renderer",
          "ytd-brand-video-singleton-renderer",
          "ytd-brand-video-shelf-renderer",
          "ytd-companion-slot-renderer",
          "ytd-action-companion-ad-renderer",
          "#masthead-ad",
          "#player-ads",
          '[data-zc-ad="1"]',
          "ytd-rich-item-renderer:has(ytd-ad-slot-renderer)",
          "ytd-rich-section-renderer:has(ytd-ad-slot-renderer)",
          "ytd-item-section-renderer:has(> #contents > ytd-ad-slot-renderer:only-child)",
          "ytd-item-section-renderer:has(> #contents > ytd-search-pyv-renderer:only-child)",
        ];
        style.textContent = selectors
          .map((s) => `${s} { display: none !important; }`)
          .join("\n");
        (document.head || document.documentElement).appendChild(style);
        styleElements.sponsored = style;
      }

      killSponsoredVideos();
      scanSponsored();

      if (!sponsoredObserver) {
        const start = () => {
          if (!document.body || sponsoredObserver) return;
          sponsoredObserver = new MutationObserver(() => {
            clearTimeout(sponsoredTimer);
            sponsoredTimer = setTimeout(() => {
              scanSponsored();
              killSponsoredVideos();
            }, 400);
          });
          sponsoredObserver.observe(document.body, { childList: true, subtree: true });
        };
        if (document.body) start();
        else document.addEventListener("DOMContentLoaded", start, { once: true });
      }
    } else {
      if (styleElements.sponsored) {
        styleElements.sponsored.remove();
        delete styleElements.sponsored;
      }
      if (sponsoredObserver) {
        sponsoredObserver.disconnect();
        sponsoredObserver = null;
      }
      clearTimeout(sponsoredTimer);
      document.querySelectorAll('[data-zc-ad="1"]').forEach((el) => {
        el.removeAttribute("data-zc-ad");
        el.style.removeProperty("display");
      });
    }
  }

  function hideEl(el) {
    el.setAttribute("data-zc-ad", "1");
    el.style.setProperty("display", "none", "important");
  }

  function scanSponsored() {
    const AD_ROOT =
      "ytd-ad-slot-renderer, ytd-in-feed-ad-layout-renderer, ytd-search-pyv-renderer, " +
      "ytd-promoted-sparkles-web-renderer, ytd-display-ad-renderer";

    document
      .querySelectorAll("ad-badge-view-model, feed-ad-metadata-view-model")
      .forEach((a) => {
        let root = a.closest(AD_ROOT);
        while (root && root.parentElement && root.parentElement.closest(AD_ROOT)) {
          root = root.parentElement.closest(AD_ROOT);
        }
        if (root) hideEl(root);
      });
  }

  // Mute and pause video previews inside hidden ads so they can't make sound
  function killSponsoredVideos() {
    document
      .querySelectorAll(
        '[data-zc-ad="1"] video, ytd-ad-slot-renderer video, ' +
        "ytd-in-feed-ad-layout-renderer video, ytd-promoted-sparkles-web-renderer video, " +
        "ytd-display-ad-renderer video, ytd-search-pyv-renderer video",
      )
      .forEach((v) => {
        try {
          v.muted = true;
          v.pause();
          v.removeAttribute("autoplay");
        } catch (e) {}
      });
  }

  function areSameVideo(previousUrl, newUrl) {
    try {
      const getSearchWithoutT = (url) => {
        const { search } = new URL(url);
        const params = new URLSearchParams(search);
        params.delete("t");
        return params.toString();
      };
      return getSearchWithoutT(previousUrl) === getSearchWithoutT(newUrl);
    } catch (e) {
      return false;
    }
  }

  const urlObserver = new MutationObserver(() => {
    const currentUrl = window.location.href;
    if (lastUrl !== currentUrl) {
      if (lastUrl && areSameVideo(lastUrl, currentUrl)) {
        lastUrl = currentUrl;
        return;
      }
      lastUrl = currentUrl;
      setTimeout(() => {
        updatePlayerQuality();
      }, 1000);
    }
  });

  if (document.body) {
    urlObserver.observe(document.body, {
      childList: true,
      subtree: true,
    });
  } else {
    const bodyObserver = new MutationObserver(() => {
      if (document.body) {
        bodyObserver.disconnect();
        urlObserver.observe(document.body, {
          childList: true,
          subtree: true,
        });
      }
    });
    bodyObserver.observe(document.documentElement, { childList: true });
  }

  browser.storage.onChanged.addListener((changes) => {
    if (changes.youtubeSettings) {
      const newSettings = changes.youtubeSettings.newValue;
      const oldSettings = settings;
      settings = { ...settings, ...newSettings };

      if (oldSettings.hideRecommended !== settings.hideRecommended) {
        applyHideRecommended();
      }
      if (oldSettings.hideShorts !== settings.hideShorts) {
        applyHideShorts();
      }
      if (oldSettings.hideComments !== settings.hideComments) {
        applyHideComments();
      }
      if (oldSettings.hideExplore !== settings.hideExplore) {
        applyHideExplore();
      }
      if (oldSettings.hideMoreFromYoutube !== settings.hideMoreFromYoutube) {
        applyHideMoreFromYoutube();
      }
      if (oldSettings.disableAutoplay !== settings.disableAutoplay) {
        applyDisableAutoplay();
      }
      if (oldSettings.hideEndCards !== settings.hideEndCards) {
        applyHideEndCards();
      }
      if (oldSettings.hideAnnotations !== settings.hideAnnotations) {
          applyHideAnnotations();
      }
      if (oldSettings.defaultQuality !== settings.defaultQuality) {
        const quality = qualityMap[settings.defaultQuality] || "medium";
        setQuality(quality);
      }
      if (oldSettings.defaultAudioTrack !== settings.defaultAudioTrack) {
        syncAudioScript(settings.defaultAudioTrack);
      }
      if (oldSettings.hideSponsored !== settings.hideSponsored) {
        applyHideSponsored();
      }
    }
  });

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", loadSettings);
  } else {
    loadSettings();
  }
})();

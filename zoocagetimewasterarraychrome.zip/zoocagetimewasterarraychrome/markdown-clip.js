// Injected on demand by the service worker (tracker.js) into the page's isolated world.
// Chrome port: image fetching + AVIF encoding now happen in the extension (offscreen document),
// because content scripts can't fetch cross-origin images or spawn extension workers.
(async function () {
    if (window.zoocageMarkdownClipRunning) {
        console.log('Markdown clip already running, skipping...');
        return;
    }
    window.zoocageMarkdownClipRunning = true;

    try {
        async function captureHighlightedTerms() {
            const highlightedTerms = {};
            document.querySelectorAll('mark.zoocage-highlight').forEach(mark => {
                const actualText = mark.textContent.trim().toLowerCase();
                const bgColor = window.getComputedStyle(mark).backgroundColor;
                if (actualText && bgColor && !highlightedTerms[actualText]) {
                    highlightedTerms[actualText] = bgColor;
                }
            });
            return { terms: highlightedTerms, cjkMode: window.zoocageCJKMode || false };
        }

        const settings = await browser.storage.local.get({
            markdownParser: 'defuddle',
            markdownIncludeTitle: true,
            markdownIncludeUrl: true,
            markdownIncludeAuthor: true,
            markdownIncludeDate: true,
            markdownPreserveTableLinebreaks: false,
            markdownImageMode: 'none',
            avifColorMode: 'color'
        });

        const highlightData = await captureHighlightedTerms();

        if (typeof Defuddle === 'undefined') {
            alert('Defuddle library not loaded. Please try again.');
            return;
        }

        const defuddle = new Defuddle(document, {
            url: document.URL,
            removeImages: settings.markdownImageMode === 'none'
        });
        const article = defuddle.parse();

        if (typeof TurndownService === 'undefined') {
            alert('Turndown library not loaded. Please try again.');
            return;
        }

        if (!article || !article.content) {
            alert('Could not extract content from this page');
            return;
        }

        // ---- swap in the highest-resolution srcset candidates ----
        const originalImages = new Map();

        document.querySelectorAll('img, source').forEach(elem => {
            if (!elem.srcset) return;

            const srcsetEntries = elem.srcset.split(',').map(entry => {
                const parts = entry.trim().split(/\s+/);
                let width;

                if (parts.length > 1) {
                    if (parts[1].endsWith('w')) {
                        width = parseInt(parts[1]);
                    } else if (parts[1].endsWith('x')) {
                        const match = parts[0].match(/\/(\d+)\/\d+\//);
                        width = match ? parseInt(match[1]) * parseFloat(parts[1]) : parseFloat(parts[1]) * 1000;
                    } else {
                        width = 1;
                    }
                } else {
                    const match = parts[0].match(/\/(\d+)\/\d+\//);
                    width = match ? parseInt(match[1]) : 1;
                }

                return { url: parts[0], width: width };
            });

            srcsetEntries.sort((a, b) => b.width - a.width);
            const target = srcsetEntries[0];

            if (target && target.url) {
                const fullUrl = target.url.startsWith('http') ? target.url :
                    new URL(target.url, window.location.href).href;

                let imgElement = elem;
                if (elem.tagName === 'SOURCE') {
                    const picture = elem.closest('picture');
                    if (picture) imgElement = picture.querySelector('img');
                }

                if (imgElement && imgElement.src) {
                    originalImages.set(imgElement.src, fullUrl);
                    originalImages.set(imgElement.src.split('?')[0], fullUrl);
                    originalImages.set(imgElement.src.split('?')[0].split('/').pop(), fullUrl);
                }

                srcsetEntries.forEach(entry => {
                    const entryUrl = entry.url.startsWith('http') ? entry.url :
                        new URL(entry.url, window.location.href).href;
                    originalImages.set(entryUrl, fullUrl);
                    originalImages.set(entryUrl.split('?')[0], fullUrl);
                    originalImages.set(entryUrl.split('?')[0].split('/').pop(), fullUrl);
                });
            }
        });

        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = article.content;
        tempDiv.querySelectorAll('img').forEach(img => {
            if (!img.src) return;
            const imgSrc = img.src.split('?')[0];
            const imgFilename = imgSrc.split('/').pop();
            const betterUrl = originalImages.get(img.src) ||
                originalImages.get(imgSrc) ||
                originalImages.get(imgFilename);
            if (betterUrl && betterUrl !== img.src) img.src = betterUrl;
        });
        article.content = tempDiv.innerHTML;

        // ---- AVIF embedding (done by the extension, not the page) ----
        if (settings.markdownImageMode === 'avif') {
            const parser = new DOMParser();
            const doc = parser.parseFromString(article.content, 'text/html');
            const images = Array.from(doc.querySelectorAll('img'));

            if (images.length > 0) {
                const notification = document.createElement('div');
                notification.textContent = `Processing ${images.length} image${images.length !== 1 ? 's' : ''}... Please wait 5-60 seconds.`;
                notification.style.cssText = `
                    position: fixed;
                    top: 50%;
                    left: 50%;
                    transform: translate(-50%, -50%);
                    background: #0e639c;
                    color: #fff;
                    padding: 1.5rem 2rem;
                    border-radius: 8px;
                    z-index: 2147483647;
                    font-weight: 600;
                    font-size: 1.1rem;
                    box-shadow: 0 8px 24px rgba(0,0,0,0.5);
                `;
                document.body.appendChild(notification);
                setTimeout(() => { if (notification.parentNode) notification.remove(); }, 15000);
            }

            for (let i = 0; i < images.length; i++) {
                const img = images[i];

                if (!img.src || (!img.src.startsWith('http') && !img.src.startsWith('data:'))) {
                    continue;
                }

                try {
                    const r = await browser.runtime.sendMessage({
                        type: 'processImageAVIF',
                        url: img.src,
                        grayscale: settings.avifColorMode === 'grayscale'
                    });
                    if (!r || !r.hash) throw new Error((r && r.error) || 'no response');
                    img.src = `avif-cache://${r.hash}#${r.size}`;
                } catch (error) {
                    console.error(`✗ Failed ${i + 1} (${img.src.substring(0, 80)}):`, error);
                    img.remove();
                }
            }

            doc.querySelectorAll('img').forEach((img) => {
                const src = img.getAttribute('src') || '';
                if (!src.startsWith('avif-cache://')) img.remove();
            });

            // Remove links left empty after their image was removed
            doc.querySelectorAll('a').forEach((a) => {
                if (!a.textContent.trim() && !a.querySelector('img, video')) a.remove();
            });

            article.content = doc.body.innerHTML;
        }

        // ---- HTML -> Markdown ----
        const turndownService = new TurndownService({
            headingStyle: 'atx',
            hr: '---',
            bulletListMarker: '-',
            codeBlockStyle: 'fenced',
            fence: '```',
            emDelimiter: '_',
            strongDelimiter: '**',
            linkStyle: 'inlined'
        });

        turndownService.addRule('removeImageLinks', {
            filter: function (node) {
                if (settings.markdownImageMode === 'none' && node.nodeName === 'A' && node.getAttribute('href')) {
                    const href = node.getAttribute('href');
                    return /\.(jpg|jpeg|png|gif|webp|svg|bmp|ico|avif)(\?.*)?$/i.test(href);
                }
                return false;
            },
            replacement: function () { return ''; }
        });

        turndownService.addRule('imageNewline', {
            filter: 'img',
            replacement: function (content, node) {
                const alt = node.alt || '';
                const src = node.getAttribute('src') || '';
                const title = node.title || '';
                const escapedAlt = alt.replace(/"/g, '\\"');

                if (title) {
                    return `\n\n![${escapedAlt}](${src})\n_${title}_\n\n`;
                }
                return `\n\n![${escapedAlt}](${src})\n\n`;
            }
        });

        turndownService.addRule('strikethrough', {
            filter: ['del', 's', 'strike'],
            replacement: function (content) { return '~~' + content + '~~'; }
        });

        turndownService.addRule('tables', {
            filter: 'table',
            replacement: function (content, node) {
                const rows = Array.from(node.querySelectorAll('tr'));
                if (rows.length === 0) return content;

                const tableData = rows.map(row => {
                    return Array.from(row.querySelectorAll('th, td')).map(cell => {
                        let cellText = cell.textContent.trim();
                        if (settings.markdownPreserveTableLinebreaks) {
                            cellText = cellText.replace(/\n/g, '<br>');
                        } else {
                            cellText = cellText.replace(/\n/g, ' ');
                        }
                        return cellText;
                    });
                });

                if (tableData.length === 0) return content;

                const hasHeader = node.querySelector('thead') ||
                    (rows[0] && rows[0].querySelector('th'));

                let markdown = '\n';

                tableData.forEach((rowData, index) => {
                    const escapedCells = rowData.map(cell => cell.replace(/\|/g, '\\|'));
                    markdown += '| ' + escapedCells.join(' | ') + ' |\n';

                    if (index === 0 && hasHeader) {
                        markdown += '| ' + rowData.map(() => '---').join(' | ') + ' |\n';
                    }
                });

                return markdown + '\n';
            }
        });

        turndownService.addRule('taskListItems', {
            filter: function (node) {
                return node.type === 'checkbox' && node.parentNode.nodeName === 'LI';
            },
            replacement: function (content, node) {
                return (node.checked ? '[x] ' : '[ ] ');
            }
        });

        turndownService.addRule('codeBlocks', {
            filter: function (node) {
                return node.nodeName === 'PRE';
            },
            replacement: function (content, node) {
                const text = node.textContent.replace(/\n$/, '');
                // use a longer fence if the code itself contains ```
                let fence = '```';
                while (text.includes(fence)) fence += '`';
                return '\n' + fence + '\n' + text + '\n' + fence + '\n';
            }
        });

        if (settings.markdownImageMode === 'none') {
            turndownService.remove(['script', 'style', 'noscript', 'iframe', 'img']);
        } else {
            turndownService.remove(['script', 'style', 'noscript', 'iframe']);
        }

        let markdown = turndownService.turndown(article.content);

        const parts = markdown.split(/(```[\s\S]*?```)/g);
        markdown = parts.map((part, i) => {
            if (i % 2 === 1) return part; // fenced code, leave untouched
            return part
                .replace(/(\w+)\s+([a-z])\b/gi, function (match, word, letter) {
                    return ['s', 't', 'd'].includes(letter.toLowerCase()) ? word + letter : match;
                })
                .replace(/(\w+)\s+'s\b/gi, "$1's");
        }).join('');

        const fixedHighlightedTerms = {};
        Object.entries(highlightData.terms).forEach(([term, color]) => {
            fixedHighlightedTerms[term] = color;
            if (term.match(/[std]$/i)) {
                fixedHighlightedTerms[term.slice(0, -1)] = color;
            }
        });

        const title = article.title || document.title || 'Untitled';
        const url = window.location.href;
        const author = article.byline || article.author || '';

        let frontmatter = '---\n';
        if (settings.markdownIncludeTitle && title) frontmatter += `title: "${title.replace(/"/g, '\\"')}"\n`;
        if (settings.markdownIncludeUrl && url) frontmatter += `url: "${url}"\n`;
        if (settings.markdownIncludeAuthor && author) frontmatter += `author: "${author.replace(/"/g, '\\"')}"\n`;
        if (settings.markdownIncludeDate) frontmatter += `date: "${new Date().toISOString()}"\n`;
        frontmatter += '---\n\n';

        const fullMarkdown = frontmatter + markdown;

        browser.runtime.sendMessage({
            type: 'markdownClipResult',
            markdown: fullMarkdown,
            title: title,
            url: url,
            autoRender: settings.markdownImageMode === 'avif' && fullMarkdown.includes('avif-cache://'),
            highlightedTerms: fixedHighlightedTerms,
            cjkMode: highlightData.cjkMode
        });
    } catch (error) {
        console.error('Markdown clip error:', error);
        alert('Markdown clip failed: ' + (error && error.message ? error.message : error));
    } finally {
        setTimeout(() => { window.zoocageMarkdownClipRunning = false; }, 1000);
    }
})();

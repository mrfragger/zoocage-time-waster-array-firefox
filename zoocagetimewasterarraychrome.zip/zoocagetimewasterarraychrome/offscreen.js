// Offscreen document: fetches, resizes and AVIF-encodes images for "Clip as Markdown".
// Runs on the extension origin, so it can fetch cross-origin images (host_permissions),
// spawn the module worker, and write to the same IndexedDB as the service worker.

const MAX_W = 500;
const MAX_H = 375;
const MAX_WORKERS = Math.max(1, Math.min(navigator.hardwareConcurrency || 2, 4));
const IDLE_CLOSE_MS = 60000;

// ---------- tiny AVIF cache (same DB/store/record format as tracker.js) ----------
const cache = {
  db: null,
  async init() {
    if (this.db) return;
    await new Promise((resolve, reject) => {
      const req = indexedDB.open('zoocageAVIFCache', 1);
      req.onerror = () => reject(req.error);
      req.onsuccess = () => { this.db = req.result; resolve(); };
      req.onupgradeneeded = (e) => {
        const db = e.target.result;
        if (!db.objectStoreNames.contains('images')) db.createObjectStore('images');
      };
    });
  },
  async set(key, blob) {
    await this.init();
    return new Promise((resolve, reject) => {
      const store = this.db.transaction(['images'], 'readwrite').objectStore('images');
      const req = store.put({ blob, size: blob.size, timestamp: Date.now() }, key);
      req.onerror = () => reject(req.error);
      req.onsuccess = () => resolve();
    });
  },
};

// ---------- worker pool ----------
const pool = [];
const waiters = [];

function acquire() {
  const idle = pool.find((w) => !w.busy);
  if (idle) { idle.busy = true; return Promise.resolve(idle); }
  if (pool.length < MAX_WORKERS) {
    const w = new Worker('avif-encoder.js', { type: 'module' });
    w.busy = true;
    pool.push(w);
    return Promise.resolve(w);
  }
  return new Promise((resolve) => waiters.push(resolve));
}

function release(worker) {
  const next = waiters.shift();
  if (next) next(worker);
  else worker.busy = false;
}

function encodeWith(worker, imageData, quality, effort) {
  return new Promise((resolve, reject) => {
    const onMessage = (e) => {
      worker.removeEventListener('message', onMessage);
      worker.removeEventListener('error', onError);
      if (e.data.error) reject(new Error(e.data.error));
      else resolve(e.data.blob);
    };
    const onError = (err) => {
      worker.removeEventListener('message', onMessage);
      worker.removeEventListener('error', onError);
      reject(new Error(err.message || 'worker error'));
    };
    worker.addEventListener('message', onMessage);
    worker.addEventListener('error', onError);
    worker.postMessage({ imageData, quality, effort }, [imageData.data.buffer]);
  });
}

// ---------- decode / encode job ----------
async function decode(blob) {
  try {
    return await createImageBitmap(blob);
  } catch (e) {
    // fallback (e.g. SVG)
    const url = URL.createObjectURL(blob);
    try {
      const img = new Image();
      img.src = url;
      await img.decode();
      return await createImageBitmap(img);
    } finally {
      URL.revokeObjectURL(url);
    }
  }
}

async function handleEncode({ url, hash, grayscale }) {
  const resp = await fetch(url);
  if (!resp.ok) throw new Error('HTTP ' + resp.status);
  const bitmap = await decode(await resp.blob());

  const scale = Math.min(MAX_W / bitmap.width, MAX_H / bitmap.height, 1);
  const w = Math.max(1, Math.round(bitmap.width * scale));
  const h = Math.max(1, Math.round(bitmap.height * scale));

  const canvas = new OffscreenCanvas(w, h);
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  ctx.drawImage(bitmap, 0, 0, w, h);
  bitmap.close();

  const imageData = ctx.getImageData(0, 0, w, h);
  if (grayscale) {
    const d = imageData.data;
    for (let i = 0; i < d.length; i += 4) {
      const g = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
      d[i] = d[i + 1] = d[i + 2] = g;
    }
  }

  const worker = await acquire();
  try {
    const blob = await encodeWith(worker, imageData, 50, 8);
    await cache.set(hash, blob);
    return { size: blob.size };
  } finally {
    release(worker);
  }
}

// ---------- messaging + idle shutdown ----------
let active = 0;
let idleTimer = null;

function scheduleClose() {
  clearTimeout(idleTimer);
  idleTimer = setTimeout(() => {
    if (active === 0) chrome.runtime.sendMessage({ type: 'closeOffscreen' }).catch(() => {});
  }, IDLE_CLOSE_MS);
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.target !== 'offscreen' || message.type !== 'encodeAVIF') return false;
  active++;
  clearTimeout(idleTimer);
  handleEncode(message)
    .then((r) => sendResponse(r))
    .catch((e) => sendResponse({ error: String((e && e.message) || e) }))
    .finally(() => {
      active--;
      scheduleClose();
    });
  return true;
});

scheduleClose();

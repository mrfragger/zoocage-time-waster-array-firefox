// ZooCage background service worker (Chrome MV3)
importScripts('browser-shim.js');

/* =====================================================================
   AVIF cache (IndexedDB, extension origin - shared with offscreen.js and zoocage.html)
   ===================================================================== */
class AVIFCache {
    constructor() {
        this.dbName = 'zoocageAVIFCache';
        this.storeName = 'images';
        this.db = null;
    }

    async init() {
        if (this.db) return;
        await new Promise((resolve, reject) => {
            const request = indexedDB.open(this.dbName, 1);
            request.onerror = () => reject(request.error);
            request.onsuccess = () => { this.db = request.result; resolve(); };
            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                if (!db.objectStoreNames.contains(this.storeName)) db.createObjectStore(this.storeName);
            };
        });
    }

    async _run(mode, fn) {
        await this.init();
        return new Promise((resolve, reject) => {
            const store = this.db.transaction([this.storeName], mode).objectStore(this.storeName);
            const request = fn(store);
            request.onerror = () => reject(request.error);
            request.onsuccess = () => resolve(request.result);
        });
    }

    async has(key) { return (await this._run('readonly', s => s.count(key))) > 0; }
    async get(key) { const r = await this._run('readonly', s => s.get(key)); return r ? r.blob : null; }
    getWithSize(key) { return this._run('readonly', s => s.get(key)); }
    set(key, value) {
        return this._run('readwrite', s => s.put({ blob: value, size: value.size, timestamp: Date.now() }, key));
    }
    clear() { return this._run('readwrite', s => s.clear()); }
    delete(key) { return this._run('readwrite', s => s.delete(key)); }
    getAllKeys() { return this._run('readonly', s => s.getAllKeys()); }
}

/* =====================================================================
   Helpers
   ===================================================================== */
function extractHost(url) {
    try { return new URL(url).hostname; } catch (e) { return null; }
}

// Only http(s) pages count for time tracking
function trackableHost(url) {
    try {
        const u = new URL(url);
        return (u.protocol === 'http:' || u.protocol === 'https:') ? u.hostname : null;
    } catch (e) { return null; }
}

function getDateString(date = new Date()) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

async function isWhitelisted(host) {
    if (!host) return true;
    const { whitelist = [] } = await browser.storage.local.get('whitelist');
    return whitelist.some(pattern => {
        const regexPattern = pattern.replace(/\./g, '\\.').replace(/\*/g, '.*');
        return new RegExp('^' + regexPattern + '$').test(host);
    });
}

async function hashUrl(url) {
    const data = new TextEncoder().encode(url);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(hashBuffer))
        .map(b => b.toString(16).padStart(2, '0')).join('').substring(0, 16);
}

/* =====================================================================
   Persistent state (service workers get killed after ~30s idle)
   ===================================================================== */
let activeTabId = null;
let activeTabHost = null;
let activeTabStartTime = null;
const audioPlayingTabs = new Map();
let badgeUpdateInterval = null;
let TABS_LIMIT = 3;
let MAX_TABS_ENABLED = true;

function persistState() {
    return browser.storage.session.set({
        zcState: {
            active: { tabId: activeTabId, host: activeTabHost, start: activeTabStartTime },
            audio: [...audioPlayingTabs.values()],
        },
    }).catch(() => {});
}

const stateReady = (async () => {
    try {
        const { zcState } = await browser.storage.session.get('zcState');
        if (zcState) {
            const a = zcState.active || {};
            activeTabId = a.tabId ?? null;
            activeTabHost = a.host ?? null;
            activeTabStartTime = a.start ?? null;
            (zcState.audio || []).forEach(s => audioPlayingTabs.set(s.tabId, s));
        } else {
            // fresh browser session
            const tabs = await browser.tabs.query({ active: true, currentWindow: true });
            if (tabs[0]) {
                const host = trackableHost(tabs[0].url);
                if (host) {
                    activeTabId = tabs[0].id;
                    activeTabHost = host;
                    activeTabStartTime = Date.now();
                }
            }
            const audible = await browser.tabs.query({ audible: true });
            audible.forEach(t => {
                const host = t.url && trackableHost(t.url);
                if (host) {
                    audioPlayingTabs.set(t.id, {
                        host, url: t.url, tabId: t.id,
                        startTime: Date.now(), lastCheckTime: Date.now(),
                    });
                }
            });
            await persistState();
        }
    } catch (e) {
        console.error('state restore failed', e);
    }
    await loadMaxTabsSettings();
    if (audioPlayingTabs.size > 0) startBadgeUpdates();
})();

/* =====================================================================
   Time tracking
   ===================================================================== */
// Serialise read-modify-write of timeData
let writeChain = Promise.resolve();
function queueWrite(fn) {
    writeChain = writeChain.then(fn).catch(e => console.error(e));
    return writeChain;
}

async function addTime(kind, host, seconds) {
    if (!host || seconds <= 0) return;
    if (await isWhitelisted(host)) return;
    const dateStr = getDateString();
    const { timeData = {} } = await browser.storage.local.get('timeData');
    if (!timeData[dateStr]) timeData[dateStr] = { browsing: {}, media: {} };
    if (!timeData[dateStr][kind]) timeData[dateStr][kind] = {};
    timeData[dateStr][kind][host] = (timeData[dateStr][kind][host] || 0) + seconds;
    await browser.storage.local.set({ timeData });
}

const saveBrowsingTime = (host, seconds) => queueWrite(() => addTime('browsing', host, seconds));
const saveMediaTime = (host, seconds) => queueWrite(() => addTime('media', host, seconds));

function updateBadge() {
    if (audioPlayingTabs.size === 0) {
        browser.action.setBadgeText({ text: '' });
        stopBadgeUpdates();
        return;
    }

    let totalSeconds = 0;
    const now = Date.now();
    audioPlayingTabs.forEach((state) => {
        totalSeconds += Math.floor((now - state.startTime) / 1000);
    });

    let text;
    if (totalSeconds < 900) {
        text = `${totalSeconds}`;
    } else {
        const minutes = Math.floor(totalSeconds / 60);
        if (minutes < 100) text = `${minutes}m`;
        else if (minutes < 900) text = `${minutes}`;
        else text = `${Math.floor(totalSeconds / 3600)}h`;
    }

    browser.action.setBadgeText({ text });
    browser.action.setBadgeBackgroundColor({ color: '#2d2d2d' });
}

// The per-second API call also keeps the service worker alive while audio is playing
function startBadgeUpdates() {
    if (!badgeUpdateInterval) {
        badgeUpdateInterval = setInterval(updateBadge, 1000);
        updateBadge();
    }
}

function stopBadgeUpdates() {
    if (badgeUpdateInterval) {
        clearInterval(badgeUpdateInterval);
        badgeUpdateInterval = null;
    }
}

function startTrackingActiveTab(tabId, host) {
    if (activeTabId !== null && activeTabHost && activeTabStartTime) {
        saveBrowsingTime(activeTabHost, Math.floor((Date.now() - activeTabStartTime) / 1000));
    }
    activeTabId = tabId;
    activeTabHost = host;
    activeTabStartTime = Date.now();
    persistState();
}

function stopTrackingActiveTab() {
    if (activeTabId !== null && activeTabHost && activeTabStartTime) {
        saveBrowsingTime(activeTabHost, Math.floor((Date.now() - activeTabStartTime) / 1000));
    }
    activeTabId = null;
    activeTabHost = null;
    activeTabStartTime = null;
    persistState();
}

function recordSegment(state) {
    const now = Date.now();
    const duration = Math.floor((now - state.lastCheckTime) / 1000);
    if (duration > 0) saveMediaTime(state.host, duration);
    state.lastCheckTime = now;
}

function handleAudioStart(tabId, url) {
    if (!url) return;
    const host = trackableHost(url);
    if (!host) return;

    const existing = audioPlayingTabs.get(tabId);
    const fresh = { host, url, tabId, startTime: Date.now(), lastCheckTime: Date.now() };

    if (existing) {
        if (existing.url !== url) {
            recordSegment(existing);
            audioPlayingTabs.set(tabId, fresh);
        }
    } else {
        audioPlayingTabs.set(tabId, fresh);
    }
    persistState();
    startBadgeUpdates();
}

function handleAudioStop(tabId) {
    const state = audioPlayingTabs.get(tabId);
    if (!state) return;
    recordSegment(state);
    audioPlayingTabs.delete(tabId);
    persistState();
    updateBadge();
}

// Flush accumulated media time for all playing tabs
function flushAudioSegments() {
    const now = Date.now();
    audioPlayingTabs.forEach((state) => {
        const duration = Math.floor((now - state.lastCheckTime) / 1000);
        if (duration > 0) saveMediaTime(state.host, duration);
        state.lastCheckTime = now;
    });
    persistState();
}

browser.tabs.onActivated.addListener(async (activeInfo) => {
    await stateReady;
    try {
        const tab = await browser.tabs.get(activeInfo.tabId);
        const host = trackableHost(tab.url);
        if (host) {
            startTrackingActiveTab(activeInfo.tabId, host);
            flushAudioSegments();
        } else {
            stopTrackingActiveTab();
        }
    } catch (e) {}
});

browser.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
    await stateReady;
    if (changeInfo.audible !== undefined) {
        if (changeInfo.audible && tab && tab.url) handleAudioStart(tabId, tab.url);
        else handleAudioStop(tabId);
    }
    if (changeInfo.url && tabId === activeTabId) {
        const newHost = trackableHost(changeInfo.url);
        if (newHost !== activeTabHost) startTrackingActiveTab(tabId, newHost);
    }
});

browser.tabs.onRemoved.addListener(async (tabId) => {
    await stateReady;
    if (tabId === activeTabId) stopTrackingActiveTab();
    handleAudioStop(tabId);
});

browser.windows.onFocusChanged.addListener(async (windowId) => {
    await stateReady;
    if (windowId === browser.windows.WINDOW_ID_NONE) {
        stopTrackingActiveTab();
    } else {
        const tabs = await browser.tabs.query({ active: true, windowId });
        if (tabs[0]) {
            const host = trackableHost(tabs[0].url);
            if (host) {
                startTrackingActiveTab(tabs[0].id, host);
                flushAudioSegments();
            } else {
                stopTrackingActiveTab();
            }
        }
    }
});

browser.windows.onRemoved.addListener(async () => {
    await stateReady;
    flushAudioSegments();
});

// Heartbeat: checkpoints media time and revives the badge counter if the worker was restarted
browser.alarms.get('zc-heartbeat').then(a => {
    if (!a) browser.alarms.create('zc-heartbeat', { periodInMinutes: 0.5 });
});

browser.alarms.onAlarm.addListener(async (alarm) => {
    if (alarm.name !== 'zc-heartbeat') return;
    await stateReady;
    if (audioPlayingTabs.size > 0) {
        flushAudioSegments();
        startBadgeUpdates();
    }
});

browser.runtime.onConnect.addListener(async (port) => {
    await stateReady;

    if (port.name === 'popup') {
        const now = Date.now();
        const promises = [];
        audioPlayingTabs.forEach((state) => {
            const duration = Math.floor((now - state.lastCheckTime) / 1000);
            if (duration > 0) {
                promises.push(saveMediaTime(state.host, duration));
                state.lastCheckTime = now;
            }
        });
        persistState();
        Promise.all(promises).then(() => {
            try { port.postMessage({ updated: true }); } catch (e) {}
        });
    }

    if (port.name === 'reset-host') {
        port.onMessage.addListener((msg) => {
            audioPlayingTabs.forEach((state) => {
                if (state.host === msg.host) {
                    state.startTime = Date.now();
                    state.lastCheckTime = Date.now();
                }
            });
            persistState();
        });
    }
});

/* =====================================================================
   Site blocking + image blocking  (declarativeNetRequest replaces blocking webRequest)
   ===================================================================== */
let dnrChain = Promise.resolve();
function syncBlockRules() {
    dnrChain = dnrChain.then(doSyncBlockRules).catch(e => console.error('DNR sync failed', e));
    return dnrChain;
}

async function doSyncBlockRules() {
    const {
        siteBlockTimestamps = {},
        blockSettings = {},
        globalBlockingEnabled = false,
    } = await browser.storage.local.get(['siteBlockTimestamps', 'blockSettings', 'globalBlockingEnabled']);

    const rules = [];
    let id = 1;

    // 1) Blocked sites -> blocked.html#<original url>   (exact hostname match, like before)
    const blockedPage = browser.runtime.getURL('blocked.html');
    Object.keys(siteBlockTimestamps).forEach((host) => {
        rules.push({
            id: id++,
            priority: 10,
            action: { type: 'redirect', redirect: { regexSubstitution: blockedPage + '#\\0' } },
            condition: {
                regexFilter: '^https?://' + escapeRegex(host) + '(:[0-9]+)?([/?#].*)?$',
                resourceTypes: ['main_frame'],
            },
        });
    });

    // 2) Image blocking (initiator = page that requested the image)
    if (globalBlockingEnabled) {
        const keepRequestDomains = ['i.ytimg.com', 'yt3.ggpht.com'];
        const siteKeys = Object.keys(blockSettings).filter(k => k !== 'global' && k !== 'local-files');
        const siteBlock = siteKeys.filter(k => blockSettings[k] && blockSettings[k].blockImages);

        if (siteBlock.length) {
            rules.push({
                id: id++,
                priority: 5,
                action: { type: 'block' },
                condition: {
                    resourceTypes: ['image'],
                    initiatorDomains: siteBlock,
                    excludedRequestDomains: keepRequestDomains,
                },
            });
        }

        if (blockSettings.global && blockSettings.global.blockImages) {
            rules.push({
                id: id++,
                priority: 1,
                action: { type: 'block' },
                condition: {
                    resourceTypes: ['image'],
                    // sites with their own entry are handled above; never block our own pages
                    excludedInitiatorDomains: [...siteKeys, browser.runtime.id],
                    excludedRequestDomains: keepRequestDomains,
                },
            });
        }
    }

    const existing = await browser.declarativeNetRequest.getDynamicRules();
    await browser.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: existing.map(r => r.id),
        addRules: rules,
    });
}

/* =====================================================================
   Toolbar icon (Chrome can't use SVG icons -> PNG; red X when image blocking is active)
   ===================================================================== */
const ICON_PATHS = { 16: 'icon-16.png', 32: 'icon-32.png', 48: 'icon-48.png' };

async function updateBadgeColor() {
    const { globalBlockingEnabled = false } = await browser.storage.local.get('globalBlockingEnabled');
    browser.action.setBadgeBackgroundColor({ color: globalBlockingEnabled ? '#ff0000' : '#2d2d2d' });
}

async function updateIconForBlocking() {
    try {
        const tabs = await browser.tabs.query({ active: true, currentWindow: true });
        if (!tabs || !tabs[0]) return;

        const url = tabs[0].url;
        if (!url || !/^(https?|file):/.test(url)) return;

        const host = extractHost(url);
        const { blockSettings = {}, globalBlockingEnabled = false } =
            await browser.storage.local.get(['blockSettings', 'globalBlockingEnabled']);

        if (!globalBlockingEnabled) {
            browser.action.setIcon({ path: ICON_PATHS });
            return;
        }

        const globalSettings = blockSettings.global || {};
        const siteSettings = host ? blockSettings[host] : null;
        const imageBlockingActive = (siteSettings && siteSettings.blockImages) ||
                                    (!siteSettings && globalSettings.blockImages);

        if (imageBlockingActive) {
            const resp = await fetch(browser.runtime.getURL('icon-48.png'));
            const bitmap = await createImageBitmap(await resp.blob());
            const canvas = new OffscreenCanvas(48, 48);
            const ctx = canvas.getContext('2d');
            ctx.drawImage(bitmap, 0, 0, 48, 48);
            ctx.strokeStyle = '#FF0000';
            ctx.lineWidth = 4;
            ctx.lineCap = 'round';
            ctx.beginPath();
            ctx.moveTo(8, 8); ctx.lineTo(40, 40);
            ctx.moveTo(40, 8); ctx.lineTo(8, 40);
            ctx.stroke();
            browser.action.setIcon({ imageData: ctx.getImageData(0, 0, 48, 48) });
        } else {
            browser.action.setIcon({ path: ICON_PATHS });
        }
    } catch (e) {
        console.error('icon update failed', e);
    }
}

browser.tabs.onActivated.addListener(updateIconForBlocking);
browser.tabs.onUpdated.addListener((tabId, changeInfo) => {
    if (changeInfo.status === 'complete') updateIconForBlocking();
});

/* =====================================================================
   Markdown clip (injection)
   ===================================================================== */
async function pageNotice(tabId, message) {
    await browser.scripting.executeScript({
        target: { tabId },
        args: [message],
        func: (msg) => {
            const n = document.createElement('div');
            n.textContent = msg;
            n.style.cssText = 'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:#d13438;color:#fff;padding:1.5rem 2rem;border-radius:8px;z-index:2147483647;font-weight:600;font-size:1.1rem;box-shadow:0 8px 24px rgba(0,0,0,0.5);';
            document.body.appendChild(n);
            setTimeout(() => n.remove(), 5000);
        },
    });
}

async function ensureClipLibs(tabId) {
    const [chk] = await browser.scripting.executeScript({
        target: { tabId },
        func: () => ({ d: typeof Defuddle !== 'undefined', t: typeof TurndownService !== 'undefined' }),
    });
    const files = [];
    if (!chk.result.d) files.push('defuddle.js');
    if (!chk.result.t) files.push('turndown.js');
    if (files.length) await browser.scripting.executeScript({ target: { tabId }, files });
}

async function runMarkdownClip(tab) {
    if (!tab || !tab.url || !/^(https?|file):/.test(tab.url)) return;
    try {
        const [running] = await browser.scripting.executeScript({
            target: { tabId: tab.id },
            func: () => window.zoocageMarkdownClipRunning || false,
        });
        if (running && running.result) {
            await pageNotice(tab.id, 'Markdown clip already used! Refresh page (F5) to clip again.');
            return;
        }
        await ensureClipLibs(tab.id);
        await browser.scripting.executeScript({
            target: { tabId: tab.id },
            files: ['browser-shim.js', 'markdown-clip.js'],
        });
    } catch (e) {
        console.error('Markdown clip failed:', e);
        pageNotice(tab.id, 'Markdown clip failed! Refresh page (F5) and try again.').catch(() => {});
    }
}

browser.commands.onCommand.addListener(async (command) => {
    if (command === 'clip-markdown') {
        const tabs = await browser.tabs.query({ active: true, currentWindow: true });
        if (tabs[0]) runMarkdownClip(tabs[0]);
    }
});

// Runs inside the page (isolated world) - must be self-contained
function extractFreqText() {
    try {
        const defuddle = new Defuddle(document, { url: document.URL, removeImages: true });
        const article = defuddle.parse();
        if (!article || !article.content) return '';

        const turndownService = new TurndownService({ headingStyle: 'atx' });
        turndownService.remove(['script', 'style', 'noscript', 'iframe', 'img', 'nav', 'aside', 'figure']);
        let markdown = turndownService.turndown(article.content);

        markdown = markdown.replace(/^---[\s\S]*?---/m, '');
        markdown = markdown.replace(/^#{1,6}\s+.*/gm, '');
        markdown = markdown.replace(/!\[.*?\]\(.*?\)/g, '');
        markdown = markdown.replace(/\[([^\]]+)\]\([^)]+\)/g, '$1');
        markdown = markdown.replace(/[*_`#>|]/g, ' ');
        return markdown;
    } catch (e) {
        return '';
    }
}

async function getPageFreqText() {
    const tabs = await browser.tabs.query({ active: true, currentWindow: true });
    if (!tabs[0]) return { error: 'No active tab' };
    await ensureClipLibs(tabs[0].id);
    const [res] = await browser.scripting.executeScript({ target: { tabId: tabs[0].id }, func: extractFreqText });
    return { text: (res && res.result) || '' };
}

/* =====================================================================
   AVIF image processing (offscreen document does the heavy lifting)
   ===================================================================== */
let creatingOffscreen = null;

async function ensureOffscreen() {
    const contexts = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
    if (contexts.length > 0) return;
    if (creatingOffscreen) { await creatingOffscreen; return; }
    creatingOffscreen = browser.offscreen.createDocument({
        url: 'offscreen.html',
        reasons: ['WORKERS'],
        justification: 'Encode clipped images to AVIF in web workers',
    });
    try { await creatingOffscreen; } finally { creatingOffscreen = null; }
}

async function processImageAVIF(url, grayscale) {
    const hash = await hashUrl(url);
    const cache = new AVIFCache();
    if (await cache.has(hash)) {
        const rec = await cache.getWithSize(hash);
        return { hash, size: rec.size, cached: true };
    }
    await ensureOffscreen();
    const res = await browser.runtime.sendMessage({ target: 'offscreen', type: 'encodeAVIF', url, hash, grayscale });
    if (!res || res.error) throw new Error((res && res.error) || 'encode failed');
    return { hash, size: res.size, cached: false };
}

async function blobToDataUrl(blob) {
    const bytes = new Uint8Array(await blob.arrayBuffer());
    let binary = '';
    const chunk = 0x8000;
    for (let i = 0; i < bytes.length; i += chunk) {
        binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
    }
    return 'data:image/avif;base64,' + btoa(binary);
}

/* =====================================================================
   Messages
   ===================================================================== */
function respondAsync(promiseFactory, sendResponse, fallback = null) {
    promiseFactory().then(sendResponse, (e) => {
        console.error(e);
        sendResponse(fallback === 'error' ? { error: String(e && e.message || e) } : fallback);
    });
    return true; // keep channel open
}

browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || message.target === 'offscreen') return false;

    if (message.action === 'maxTabsSettingsChanged') {
        loadMaxTabsSettings().then(() => unloadTabsIfNecessary());
        return false;
    }

    switch (message.type) {
        case 'getPageFreqText':
            return respondAsync(getPageFreqText, sendResponse, 'error');

        case 'processImageAVIF':
            return respondAsync(() => processImageAVIF(message.url, !!message.grayscale), sendResponse, 'error');

        case 'closeOffscreen':
            browser.offscreen.closeDocument().catch(() => {});
            return false;

        case 'syncBlockRules':
            return respondAsync(async () => { await syncBlockRules(); return true; }, sendResponse, false);

        case 'storeAVIFCache':
            return respondAsync(async () => {
                const cache = new AVIFCache();
                await cache.set(message.hash, new Blob([new Uint8Array(message.data)], { type: 'image/avif' }));
                return { success: true };
            }, sendResponse, 'error');

        case 'deleteAVIFCache':
            return respondAsync(async () => {
                await new AVIFCache().delete(message.hash);
                return { success: true };
            }, sendResponse, 'error');

        case 'checkAVIFCache':
            return respondAsync(() => new AVIFCache().has(message.hash), sendResponse, false);

        case 'getAVIFCache':
            return respondAsync(async () => {
                const blob = await new AVIFCache().get(message.hash);
                return blob ? await blobToDataUrl(blob) : null;
            }, sendResponse, null);

        case 'getAVIFCacheWithSize':
            return respondAsync(async () => {
                const rec = await new AVIFCache().getWithSize(message.hash);
                return rec ? { size: rec.size, timestamp: rec.timestamp } : null;
            }, sendResponse, null);

        case 'markdownClipResult':
            if (message.markdown) {
                const hasImages = /!\[.*?\]\(data:image\//.test(message.markdown);
                const dataId = Date.now().toString();
                browser.storage.local.set({
                    ['zcPendingMd_' + dataId]: {
                        markdown: message.markdown,
                        title: message.title || 'Markdown Clip',
                        url: message.url || '',
                        autoRender: hasImages,
                        highlightedTerms: message.highlightedTerms || {},
                        cjkMode: message.cjkMode || false,
                    },
                }).then(() => browser.tabs.create({
                    url: browser.runtime.getURL(`zoocage.html?pending=${dataId}`),
                    index: sender.tab ? sender.tab.index + 1 : undefined,
                }));
            }
            return false;

        case 'getPendingMarkdown':
            return respondAsync(async () => {
                const key = 'zcPendingMd_' + message.dataId;
                const got = await browser.storage.local.get(key);
                if (got[key]) {
                    await browser.storage.local.remove(key);
                    return got[key];
                }
                return null;
            }, sendResponse, null);
    }
    return false;
});

/* =====================================================================
   Context menus
   ===================================================================== */
const menuCreate = (props) => browser.contextMenus.create(props, () => void chrome.runtime.lastError);
const menuTitle = (id, title) => browser.contextMenus.update(id, { title }).catch(() => {});

async function createContextMenus() {
    await browser.contextMenus.removeAll();
    const isMac = (navigator.platform || '').toLowerCase().includes('mac');
    const shortcutText = isMac ? '⌘⇧X' : 'Ctrl+Shift+X';

    menuCreate({ id: 'clipMarkdown', title: `📋 Clip as Markdown ${shortcutText}`, contexts: ['all'] });
    menuCreate({ id: 'blurSite', title: '💦 Blur Site', contexts: ['all'] });
    menuCreate({ id: 'toggleImageZoom', title: '🔎 Image Zoom: Loading...', contexts: ['all'] });
    menuCreate({ id: 'blockSite', title: '🚫 Block Site', contexts: ['all'] });
    menuCreate({ id: 'toggleContentBlocking', title: '🧪 Content Blocking: Add Site', contexts: ['all'] });
    menuCreate({ id: 'toggleGrayscale', title: '👓 Grayscale: Turn ON', contexts: ['all'] });
}

async function updateContextMenus(tab) {
    const { hoverZoomEnabled = false, grayscaleEnabled = false } =
        await browser.storage.local.get(['hoverZoomEnabled', 'grayscaleEnabled']);

    menuTitle('toggleImageZoom', hoverZoomEnabled ? '🔍 Image Zoom: Turn OFF' : '🔎 Image Zoom: Turn ON');
    menuTitle('toggleGrayscale', grayscaleEnabled ? '🧬 Grayscale: Turn OFF' : '👓 Grayscale: Turn ON');

    const host = tab && tab.url && /^(https?):/.test(tab.url) ? extractHost(tab.url) : null;
    if (host) {
        const { blurSiteList = [], blockSettings = {} } =
            await browser.storage.local.get(['blurSiteList', 'blockSettings']);
        menuTitle('blurSite', blurSiteList.includes(host) ? '☁️ Unblur Site' : '💦 Blur Site');
        menuTitle('toggleContentBlocking',
            blockSettings[host] ? '🌡 Content Blocking: Remove Site' : '🧪 Content Blocking: Add Site');
    } else {
        menuTitle('blurSite', '💦 Blur Site');
        menuTitle('toggleContentBlocking', '🧪 Content Blocking: Add Site');
    }
}

async function refreshMenusForActiveTab() {
    try {
        const tabs = await browser.tabs.query({ active: true, currentWindow: true });
        if (tabs[0]) await updateContextMenus(tabs[0]);
    } catch (e) {}
}

browser.tabs.onActivated.addListener(async (info) => {
    try { updateContextMenus(await browser.tabs.get(info.tabId)); } catch (e) {}
});
browser.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete') updateContextMenus(tab);
});

browser.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes.siteBlockTimestamps || changes.blockSettings || changes.globalBlockingEnabled) syncBlockRules();
    if (changes.blockSettings || changes.globalBlockingEnabled) updateIconForBlocking();
    if (changes.globalBlockingEnabled) updateBadgeColor();
    if (changes.hoverZoomEnabled || changes.blockSettings || changes.grayscaleEnabled || changes.blurSiteList) {
        refreshMenusForActiveTab();
    }
});

browser.contextMenus.onClicked.addListener(async (info, tab) => {
    const usable = tab && tab.url && /^(https?|file):/.test(tab.url);

    if (info.menuItemId === 'toggleImageZoom') {
        const { hoverZoomEnabled = false } = await browser.storage.local.get('hoverZoomEnabled');
        await browser.storage.local.set({ hoverZoomEnabled: !hoverZoomEnabled });
        await updateContextMenus(tab);
    }

    if (info.menuItemId === 'toggleGrayscale') {
        const { grayscaleEnabled = false } = await browser.storage.local.get('grayscaleEnabled');
        await browser.storage.local.set({ grayscaleEnabled: !grayscaleEnabled });
        await updateContextMenus(tab);
    }

    if (info.menuItemId === 'blockSite') {
        if (!usable) return;
        const host = extractHost(tab.url);
        if (!host) return;
        const { siteBlockTimestamps = {} } = await browser.storage.local.get('siteBlockTimestamps');
        if (!siteBlockTimestamps[host]) {
            siteBlockTimestamps[host] = Date.now();
            await browser.storage.local.set({ siteBlockTimestamps });
            await syncBlockRules(); // rule must exist before the reload
            browser.tabs.reload(tab.id);
        }
    }

    if (info.menuItemId === 'toggleContentBlocking') {
        if (!usable) return;
        const host = extractHost(tab.url);
        if (!host) return;
        const { blockSettings = {} } = await browser.storage.local.get('blockSettings');
        if (blockSettings[host]) delete blockSettings[host];
        else blockSettings[host] = { blockImages: false, blockSVG: false };
        await browser.storage.local.set({ blockSettings });
        await updateContextMenus(tab);
    }

    if (info.menuItemId === 'clipMarkdown') {
        runMarkdownClip(tab);
    }

    if (info.menuItemId === 'blurSite') {
        if (!usable) return;
        const host = extractHost(tab.url);
        if (!host) return;

        const { blurSiteList = [], blurSettings = {} } =
            await browser.storage.local.get(['blurSiteList', 'blurSettings']);

        if (blurSiteList.includes(host)) {
            await browser.storage.local.set({ blurSiteList: blurSiteList.filter(s => s !== host) });
            browser.tabs.sendMessage(tab.id, { action: 'toggleBlur', enabled: false }).catch(() => {});
        } else {
            blurSiteList.push(host);
            if (!blurSettings[host]) blurSettings[host] = { imageBlur: 8, videoBlur: 20, invertImages: false };
            await browser.storage.local.set({ blurSiteList, blurSettings });
            browser.tabs.sendMessage(tab.id, { action: 'toggleBlur', enabled: true }).catch(() => {});
        }
        await updateContextMenus(tab);
    }
});

/* =====================================================================
   Max tabs
   ===================================================================== */
async function loadMaxTabsSettings() {
    const result = await browser.storage.local.get(['maxTabsEnabled', 'tabsLimit']);
    MAX_TABS_ENABLED = result.maxTabsEnabled !== false;
    TABS_LIMIT = result.tabsLimit || 3;
}

function isBlankTab(tab) {
    return !tab.url ||
        tab.url === 'about:blank' ||
        tab.url === 'about:newtab' ||
        tab.url.startsWith('about:home') ||
        tab.url.startsWith('chrome://newtab') ||
        tab.url.startsWith('chrome://new-tab-page') ||
        tab.url.startsWith('chrome-search://');
}

const shouldKeepTabLoaded = (tab) => tab.audible === true || isBlankTab(tab);

function unloadTabsIfNecessary() {
    if (!MAX_TABS_ENABLED) return;

    browser.tabs.query({ currentWindow: true }).then((allTabs) => {
        allTabs.sort((a, b) => a.index - b.index);

        for (let i = 0; i < Math.min(TABS_LIMIT, allTabs.length); ++i) {
            if (allTabs[i].discarded) browser.tabs.reload(allTabs[i].id);
        }
        for (let i = TABS_LIMIT; i < allTabs.length; ++i) {
            if (!allTabs[i].discarded && !shouldKeepTabLoaded(allTabs[i])) {
                browser.tabs.discard(allTabs[i].id).catch(() => {});
            }
        }
    }).catch((error) => console.error('Error managing tabs:', error));
}

// New tabs are only evaluated once they receive their first URL (state kept in session storage)
async function getPendingTabs() {
    const { zcPendingTabs = [] } = await browser.storage.session.get('zcPendingTabs');
    return zcPendingTabs;
}
const setPendingTabs = (list) => browser.storage.session.set({ zcPendingTabs: list });

browser.tabs.onCreated.addListener(async (tab) => {
    await stateReady;
    const list = await getPendingTabs();
    list.push(tab.id);
    await setPendingTabs(list);
});

browser.tabs.onUpdated.addListener(async (tabId, changeInfo) => {
    if (!changeInfo.url) return;
    await stateReady;
    const list = await getPendingTabs();
    if (list.includes(tabId)) {
        await setPendingTabs(list.filter(id => id !== tabId));
        unloadTabsIfNecessary();
    }
});

browser.tabs.onRemoved.addListener(async (tabId) => {
    await stateReady;
    const list = await getPendingTabs();
    if (list.includes(tabId)) await setPendingTabs(list.filter(id => id !== tabId));
    unloadTabsIfNecessary();
});

/* =====================================================================
   Install / startup
   ===================================================================== */
browser.runtime.onInstalled.addListener(async () => {
    const result = await browser.storage.local.get(['zoocagesnippets', 'zoocagesettings', 'markdownImageMode', 'avifColorMode']);
    if (!result.zoocagesnippets) await browser.storage.local.set({ zoocagesnippets: [] });
    if (!result.zoocagesettings) {
        await browser.storage.local.set({
            zoocagesettings: { theme: 'themesdark/gradient-dark.min.css', mode: 'dark' },
        });
    }
    if (!result.markdownImageMode) await browser.storage.local.set({ markdownImageMode: 'avif' });
    if (!result.avifColorMode) await browser.storage.local.set({ avifColorMode: 'color' });

    await createContextMenus();
    await syncBlockRules();
    updateBadgeColor();
    updateIconForBlocking();
});

browser.runtime.onStartup.addListener(() => {
    syncBlockRules();
    updateBadgeColor();
    updateIconForBlocking();
});

// Runs on every worker wake-up
updateIconForBlocking();
refreshMenusForActiveTab();

// Minimal `browser.*` compatibility layer for Chrome (MV3).
// Load this FIRST in every extension page, content script and the service worker.
//
// What it does:
//  - defines `browser` as a thin wrapper around `chrome` (Chrome MV3 APIs already return Promises)
//  - lets runtime.onMessage listeners return a Promise (Firefox style); Chrome needs sendResponse + `return true`
//  - maps browser.browserAction -> chrome.action
//  - swallows the harmless "message port closed before a response was received" rejection
//  - provides tabs.executeScript({file}) on top of chrome.scripting
(function () {
  'use strict';
  if (globalThis.__zoocageShim) return;
  if (typeof chrome === 'undefined' || !chrome.runtime) return;
  // Real Firefox: leave everything alone
  if (typeof browser !== 'undefined' && browser.runtime && browser.runtime.getBrowserInfo) return;
  globalThis.__zoocageShim = true;

  const IGNORABLE = /message port closed before a response was received/i;

  const quiet = (fn) => (...args) => {
    const p = fn(...args);
    return p && typeof p.catch === 'function'
      ? p.catch((e) => {
          if (e && IGNORABLE.test(e.message || '')) return undefined;
          throw e;
        })
      : p;
  };

  // Proxy over an empty object inheriting from `target` so Proxy invariants never trip
  const wrap = (target, overrides) =>
    new Proxy(Object.create(target), {
      get(_, key) {
        if (overrides && Object.prototype.hasOwnProperty.call(overrides, key)) return overrides[key];
        const value = target[key];
        return typeof value === 'function' ? value.bind(target) : value;
      },
      has(_, key) {
        return key in target || (overrides ? key in overrides : false);
      },
    });

  // ---- runtime.onMessage with Promise support ----
  const origOnMessage = chrome.runtime.onMessage;
  const listenerMap = new WeakMap();
  const onMessage = {
    addListener(fn) {
      if (listenerMap.has(fn)) return;
      const wrapped = (message, sender, sendResponse) => {
        let result;
        try {
          result = fn(message, sender, sendResponse);
        } catch (e) {
          console.error(e);
          return false;
        }
        if (result && typeof result.then === 'function') {
          result.then(
            (value) => sendResponse(value),
            (err) => {
              console.error(err);
              sendResponse(undefined);
            }
          );
          return true;
        }
        return result === true;
      };
      listenerMap.set(fn, wrapped);
      origOnMessage.addListener(wrapped);
    },
    removeListener(fn) {
      const w = listenerMap.get(fn);
      if (w) {
        origOnMessage.removeListener(w);
        listenerMap.delete(fn);
      }
    },
    hasListener(fn) {
      const w = listenerMap.get(fn);
      return !!w && origOnMessage.hasListener(w);
    },
  };

  const runtime = wrap(chrome.runtime, {
    onMessage,
    sendMessage: quiet(chrome.runtime.sendMessage.bind(chrome.runtime)),
  });

  const overrides = { runtime };

  if (chrome.tabs) {
    const tabOverrides = {
      sendMessage: quiet(chrome.tabs.sendMessage.bind(chrome.tabs)),
    };
    if (chrome.scripting) {
      tabOverrides.executeScript = async (tabId, details) => {
        if (details && details.code) throw new Error('tabs.executeScript({code}) is not supported in MV3');
        const res = await chrome.scripting.executeScript({
          target: { tabId },
          files: [details.file],
        });
        return res.map((r) => r.result);
      };
    }
    overrides.tabs = wrap(chrome.tabs, tabOverrides);
  }

  if (chrome.action) {
    overrides.browserAction = chrome.action;
    overrides.pageAction = chrome.action;
  }

  globalThis.browser = wrap(chrome, overrides);
})();
